//
//  CYLInteractiveTrasition.h
//  CYLTransitioning
//
//  Created by 迟钰林 on 2017/6/20.
//  Copyright © 2017年 迟钰林. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CYLBaseTransitionAnimation.h"

@interface CYLInteractiveTrasition : NSObject

@end
